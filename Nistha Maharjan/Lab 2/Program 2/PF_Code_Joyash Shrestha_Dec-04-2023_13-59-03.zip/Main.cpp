/* Program 2 */
#include <iostream>
#include <math.h>

class dist{
    int x1,y1,x2,y2;
    float dis;

    public:
    void getdata(int a,int b,int c,int d)
    {
        x1=a;
        y1=b;
        x2=c;
        y2=d;
    }

    float calcdata()
    {
        dis=sqrt(pow((x2-x1),2)+pow((y2-y1),2));
        return dis;
    }
};

using namespace std;
int main() {
    int x1,y1,x2,y2;
    float result;
    dist D;
    cout<<"Enter coordinates of x,y:";
    cin>>x1>>y1>>x2>>y2;
    D.getdata(x1,y1,x2,y2);
    result = D.calcdata();
    cout<<"\nDistance:"<<result;
    return 0;
};