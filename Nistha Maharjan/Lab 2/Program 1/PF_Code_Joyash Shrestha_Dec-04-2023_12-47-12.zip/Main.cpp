/* Sample C++ code */
#include <iostream>
using namespace std;

class rect{
    private:
    int l,b,a,p;
    public:
    void input()
    {
        cout<<"Enter length and breath of rectangle: ";
        cin>>l>>b;
    }
    int area()
    {
        a=l*b;
        return a;
    }
    int perimeter();
};

int rect::perimeter()
{
    int p;
    p=2*(l+b);
    return p;
}
int main() {
    rect R;
    int a,p;
    R.input();
    a=R.area();
    p=R.perimeter();
    cout<<"\nArea:"<<a<<"\nPerimeter:"<<p;
    return 0;
};