/* Program 3 */
#include <iostream>
using namespace std;

class num{
    int a,b;
    public:
    void getdata()
    {
        cout<<"Enter 2 numbers: ";
        cin>>a>>b;
    }

    void display()
    {
        if(a>b)
            cout<<"\n"<<a;
        else
            cout<<"\n"<<b;
    }
};
int main() {
    num N;
    N.getdata();
    N.display();
    return 0;
};